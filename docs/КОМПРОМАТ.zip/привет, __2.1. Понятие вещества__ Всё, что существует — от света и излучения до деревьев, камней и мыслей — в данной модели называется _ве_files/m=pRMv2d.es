"use strict";loaded_g_0(function(_){var window=this;
_.m("pRMv2d");
_.lWa(_.LM,class extends _.mWa{static G(){return{}}constructor(){super();this.places=new Map;this.D=null;this.S=new Set;this.R=new Set;this.L=new Set;this.J=new Set;this.F=!1;this.ha=_.Hjb(this.ta,100,this)}j(){return[...this.places.values()]}l(...a){let b=!1;for(const c of a){const d=this.places.get(c.mid);d?(!d.latLng&&c.latLng&&(d.latLng=c.latLng,b=!0),!d.fprint&&c.fprint&&(d.fprint=c.fprint,b=!0),_.gm&&(a=Object.fromEntries(Object.entries(c).filter(([e,f])=>!d[e]&&(f!==void 0||f!==""))),Object.assign(d,
a),b=!0)):(this.places.set(c.mid,Object.assign({},c)),b=!0)}b&&this.ha();return this}B(a){this.D=a?Object.assign({},a):null;for(const b of this.R)b(this.D)}V(a){this.R.add(a);this.D&&a(this.D)}Y(a){this.S.add(a);const b=this.j();b.length&&a(b)}X(a){this.L.add(a);this.F&&this.j().filter(b=>!!b.latLng).length===0&&a()}ya(a){this.J.add(a);this.F&&a()}oa(){this.F=!0;this.j().filter(a=>!!a.latLng).length===0&&this.L.forEach(a=>void a());this.J.forEach(a=>void a())}ta(){const a=this.j();if(a.length)for(const b of this.S)b(a)}});
_.F();
});
// Google Inc.
