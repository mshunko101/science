loaded_h_0(function(_){var window=this;
_.UCb=class{constructor(a){this.Im=a}};
_.t("aLUfP");
_.VCb=!1;
_.hf(_.CWa,class extends _.Jo{static Sa(){return{service:{window:_.Ko}}}constructor(a){super();this.window=a.service.window.get();this.Ba=this.Im();this.Aa=window.orientation;this.oa=()=>{const b=this.Im();var c=this.HGb()&&Math.abs(window.orientation)===90&&this.Aa===-1*window.orientation;this.Aa=window.orientation;if(b!==this.Ba||c){this.Ba=b;for(const d of this.listeners){c=new _.UCb(b);try{d(c)}catch(e){_.fa(e)}}}};this.listeners=new Set;this.window.addEventListener("resize",this.oa);this.HGb()&&
this.window.addEventListener("orientationchange",this.oa)}addListener(a){this.listeners.add(a)}removeListener(a){this.listeners.delete(a)}Im(){if(_.ta()&&_.ra()&&!navigator.userAgent.includes("GSA")){var a=_.nm(this.window);a=new _.gm(a.width,Math.round(a.width*this.window.innerHeight/this.window.innerWidth))}else a=this.jd()||(_.ta()?_.ta()&&_.ra()&&!navigator.userAgent.includes("GSA"):this.window.visualViewport)?_.nm(this.window):new _.gm(this.window.innerWidth,this.window.innerHeight);return a.height<
a.width}destroy(){this.window.removeEventListener("resize",this.oa);this.window.removeEventListener("orientationchange",this.oa)}jd(){return _.VCb}HGb(){return"orientation"in window}});
_.VCb=!0;
_.u();
});
// Google Inc.
